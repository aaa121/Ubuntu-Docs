1. Download, extract, move to /usr/local/zeppelin, and configure the zeppelin-env.sh file by exporting the following:

export JAVA_HOME=/usr/local/java/jdk1.8.0_131
export HADOOP_HOME='/usr/local/hadoop'
export HADOOP_CONF_DIR=${HADOOP_HOME}/etc/hadoop
export SPARK_HOME='/usr/local/spark'
# Dependency Management either SPARK_SUBMIT_OPTIONS by specifying the packages, jars and files or state the external dependency libraries to be distributed in SPARK_HOME/conf/spark-defaults.conf.

#If SPARK_SUBMIT_OPTIONS is not configured, the Zeppelin spark interpreter read the configuration at SPARK_HOME/conf/spark-defaults.conf.
# For more details see http://zeppelin.apache.org/docs/snapshot/interpreter/spark.html#2-loading-spark-properties

#export SPARK_SUBMIT_OPTIONS="--packages com.databricks:spark-csv_2.10:1.2.0 --jars /path/mylib1.jar,/path/mylib2.jar --files /path/mylib1.py,/path/mylib2.zip,/path/mylib3.egg"


export PATH=$PATH:$JAVA_HOME/bin:$HADOOP_HOME/sbin:$HADOOP_HOME/bin:$SPARK_HOME/bin:$SPARK_HOME/sbin

2. Set ZEPPELIN_HOME dir in bashrc file

$ sudo gedit ~/.bashrc

PASTE
export ZEPPELIN_HOME=/usr/local/zeppelin
export PATH=$PATH:$ZEPPELIN_HOME/bin


3. Change the directory permission
$ sudo chown akin:root /usr/local/zeppelin/*
$ sudo chmod 770 /usr/local/zeppelin/*

4. Edit the log4j.properties file
$ cd /usr/local/zeppelin/conf
$ sudo gedit log4j.properties

CHANGE "console" before dailyfile to "ERROR"

5. To avoid Multiple SLF4J bindings. Delete the jar file in "file:/usr/local/zeppelin/lib/slf4j-log4j12-1.7.10.jar"

$ cd /usr/local/zeppelin/lib

$ sudo mv slf4j-log4j12-1.7.10.jar /home/akin/InstallationCodes


6. You can get full list of community managed interpreters by running

$ ./bin/install-interpreter.sh --list

TO INSTALL ALL COMMUNITY MANAGED INTERPRETERS

$ ./bin/install-interpreter.sh --all

TO INSTALL A SPECIFIC INTERPRETER USE such shell, python and elasticsearch
$ ./bin/install-interpreter.sh --name md,shell,elasticsearch,python


7. Starting Apache Zeppelin from the Command Line

On all unix like platforms:

$ ./bin/zeppelin-daemon.sh start

After Zeppelin has started successfully, go to http://localhost:8080 with your web browser.


Stopping Zeppelin

$ ./bin/zeppelin-daemon.sh stop


8. 

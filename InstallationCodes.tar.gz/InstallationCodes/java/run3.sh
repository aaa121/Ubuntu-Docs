sudo update-alternatives --set java /usr/local/java/jdk1.8.0_131/bin/java
sudo update-alternatives --set javac /usr/local/java/jdk1.8.0_131/bin/javac
sudo update-alternatives --set javaws /usr/local/java/jdk1.8.0_131/bin/javaws
java -version

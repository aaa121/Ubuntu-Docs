sudo mkdir -p /usr/local/java
cd ~/Downloads
sudo mv jdk-8u131-linux-x64.tar.gz /usr/local/java/
cd /usr/local/java
sudo tar xvzf jdk-8u131-linux-x64.tar.gz
sudo gedit /etc/profile

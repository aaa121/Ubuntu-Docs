sudo addgroup hadoop
sudo adduser -ingroup hadoop hduser
ssh-keygen -t rsa -P ""


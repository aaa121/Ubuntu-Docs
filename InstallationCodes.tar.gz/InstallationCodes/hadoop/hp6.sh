su - akin
cd /usr/local/hadoop/etc/hadoop
echo "Open 'hadoop-env.sh' and change the java home to 'export JAVA_HOME=/usr/local/java/jdk1.8.0_131' and save it."

sudo gedit hadoop-env.sh

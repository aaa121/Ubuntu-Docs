cat /proc/sys/net/ipv6/conf/all/disable_ipv6
echo "Checking if ipv6 has been disabled. Expected value of 1 for Yes."
#su - hduser



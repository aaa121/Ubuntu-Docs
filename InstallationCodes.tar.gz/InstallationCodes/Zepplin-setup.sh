1. Download, extract, move to /usr/local/zeppelin, and configure the zeppelin-env.sh file by exporting the following:

export JAVA_HOME=/usr/local/java/jdk1.8.0_131
export HADOOP_HOME='/usr/local/hadoop'
export HADOOP_CONF_DIR=${HADOOP_HOME}/etc/hadoop
export SPARK_HOME='/usr/local/spark'
# Dependency Management either SPARK_SUBMIT_OPTIONS by specifying the packages, jars and files or state the external dependency libraries to be distributed in SPARK_HOME/conf/spark-defaults.conf.

#If SPARK_SUBMIT_OPTIONS is not configured, the Zeppelin spark interpreter read the configuration at SPARK_HOME/conf/spark-defaults.conf.
# For more details see http://zeppelin.apache.org/docs/snapshot/interpreter/spark.html#2-loading-spark-properties

#export SPARK_SUBMIT_OPTIONS="--packages com.databricks:spark-csv_2.10:1.2.0 --jars /path/mylib1.jar,/path/mylib2.jar --files /path/mylib1.py,/path/mylib2.zip,/path/mylib3.egg"


export PATH=$PATH:$JAVA_HOME/bin:$HADOOP_HOME/sbin:$HADOOP_HOME/bin:$SPARK_HOME/bin:$SPARK_HOME/sbin


2. You can get full list of community managed interpreters by running

$ ./bin/install-interpreter.sh --list
